from optparse import Values
import pandas as pd
from glob import glob
import os
import tkinter
import csv
import tkinter as tk
from tkinter import *
from tkinter import ttk

def subjectchoose(text_to_speech):
    def calculate_attendance():
        Subject = tx.get()
        if Subject=="":
            t='Please enter the subject name.'
            text_to_speech(t)
        os.chdir(f'C:\\Users\\hp\\Downloads\\AS\\attendance\\')
        filenames =f"C:\\Users\hp\\Downloads\\AS\\attendance\\{Subject}.csv"
        df = pd.read_csv(filenames)
      
        newdf = df 
       
        root = tkinter.Tk()
        root.title("Attendance of "+Subject)
        root.configure(background="white")
        # cs = fr"C:\Users\hp\Downloads\AS\attendance"
        # with open(cs) as file:
        #     reader = csv.reader(file)
        #     r = 0

        #     for col in reader:
        #         c = 0
        #         for row in col:

        #             label = tkinter.Label(
        #                 root,
        #                 width=10,
        #                 height=1,
        #                 fg="yellow",
        #                 font=("times", 15, " bold "),
        #                 bg="white",
        #                 text=row,
        #                 relief=tkinter.RIDGE,
        #             )
        #             label.grid(row=r, column=c)
        #             c += 1
        #         r += 1
        col = [0,1,2]
        tree = ttk.Treeview(root,columns=col,show='headings')
        tree.column(0,width=50)
        tree.column(1,width=50)
        tree.column(2,width=50)

        # tree.heading(0,text="Enrollment no")
        # tree.heading(1,text="Name")
        # tree.heading(2,text="Attendance")
        tree.place(x=10,y=10)

        for i in newdf:
            tree.insert('','end',values=(i))

        root.mainloop()
        print(type(newdf))

    subject = Tk()
   
    subject.title("Subject...")
    subject.geometry("580x320")
    #subject.resizable(0, 0)
    subject.configure(background="white")
    titl = tk.Label(subject, bg="white", relief=RIDGE, font=("arial", 24))
    titl.pack(fill=X)
    titl = tk.Label(
        subject,
        text="Which Subject of Attendance?",
        bg="white",
        fg="black",
        font=("arial",15),
    )
    titl.place(x=100, y=12)

    def Attf():
        sub = tx.get()
        if sub == "":
            t="Please enter the subject name!!!"
            text_to_speech(t)
        else:
            os.startfile(
            fr"C:\Users\hp\Downloads\AS\attendance\{sub}"
            )


    attf = tk.Button(
        subject,
        text="Check Sheets",
        command=Attf,
        bd=2,
        font=("times new roman", 15),
        bg="white",
        fg="black",
        height=2,
        width=10,
        relief=RIDGE,
    )
    attf.place(x=360, y=170)

    sub = tk.Label(
        subject,
        text="Enter Subject",
        width=10,
        height=2,
        bg="white",
        fg="black",
        bd=2,
        relief=RIDGE,
        font=("times new roman", 15),
    )
    sub.place(x=50, y=100)

    tx = tk.Entry(
        subject,
        width=15,
        bd=2,
        bg="white",
        fg="black",
        relief=RIDGE,
        font=("times", 30, "bold"),
    )
    tx.place(x=190, y=100)

    fill_a = tk.Button(
        subject,
        text="View Attendance",
        command=calculate_attendance,
        bd=2,
        font=("times new roman", 15),
        bg="white",
        fg="black",
        height=2,
        width=12,
        relief=RIDGE,
    )
    fill_a.place(x=195, y=170)
    subject.mainloop()
